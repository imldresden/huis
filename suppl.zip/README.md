# Supplement Material

This zip archive contains supplementary material for the paper "Hybrid User Interfaces: Past, Present, and Future of Complementary Cross-Device Interaction in Mixed Reality".
The zip contains the following folders and files.
In each of the folder an additional README exists to explain the further content.

## Folder: 01 Query
Files that describe the queries of the conducted literature search in more detail.

## Folder: 02 Query Processing
Python projects used to process the search results.

## File: 03 Literature Corpus.xlsx
An excel table containing all papers reviewed while our corpus creation.
Note: this file has multiple tabs:
  - "category descriptions" shows the description of each category from our corpus 
  - "critera" elaborates on the screening and elegibility criteria
  - "coded papers" shows the entire corpus, screening, eligibility, and respective coding on passing entries
  - "interaction paradigms" shows the analysis performed on the final corpus with respect to interaction
  - "web-survey export" is the adapted version of "coded papers" which is used to generate the website (see 05)

## Folder: 04 Corpus Analysis
Python project used to analyze the visually represent the coded papers.

## Folder: 05 Survey Webpage
A webpage, presenting our survey corpus with all its categories and codes.