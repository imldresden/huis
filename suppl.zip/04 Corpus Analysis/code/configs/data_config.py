#!/usr/bin/env python3

import os


class DataConfig:
    Drop_cols = [
        "PDF Link",
        "Other Devices (specify)",
        "Evaluation (Description)",
        "Other Configurations (specify)",
        "Other Codependency (Specify)"
    ]

    Int_cols = [
        "Index",
        "year",
    ]

    Str_cols = [
        "Title",
        "source",
        "Screening",
        "Eligible",
        "Use case / Area",
        "Author's Terminology",
    ]

    Categories = {
        "year": list(range(1991, 2025 + 1)),
        "year-reduced": [1991, 1997, 1999, 2004, 2005, 2006, 2007, 2009, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025],
        "source": [
            "acm",
            "ieee",
            "wiley",
            "springer",
            "refer-to-hui",
            "refer-to-dui",
            "refer-to-ad",
            "refer-to-cdt",
            "handpicked",
        ],
        "edge case": [
            "Interesting",
            "Edge Case",
        ],
        "screening": [
            "Yes",
            "No",
            "Duplicate",
        ],
        "eligibility": [
            "Yes",
            "No",
            "Removed in Screening"
        ],
        "eligibility check": [
            "content duplicate (e.g. demo) to", 
            "Summary/Position Paper", 
            "no system", 
            "pure technical frameworks", 
            "pure MR", 
            "collaboration across asymmetric devices", 
            "components not self-contained", 
            "no complementary component combination",
            "not peer reviewed",
        ],
        "use case": [
            "Development/Authoring",
            "Gaming",
            "DataVis/Data Analysis",
            "SciVis",
            "Medical",
            "Productivity",
            "Collaboration",
            "Entertainment",
            "3D Object Manipulation",
            "3D Design/Sketching",
            "Text Entry / Annotations",
            "Study",
            "Other / None",
        ],
        "terminology": [
            "Term: Hybrid UI",
            "Term: Hybrid <other>",
            "Term: Cross-Device",
            "Term: Cross-Reality",
            "Term: Multi-Device",
            "Term: Augmented Display",
            "Term: Transitional",
            "Undefined",
            "Other Terms",
        ],
        "contribution": [
            "Artifact",
            "Empirical",
            "Theory",
            "Method",
            "Dataset",
            "Opinion",
            "Survey",
        ],
        "devices": [
            "AR OST HWD",
            "AR VST HWD",
            "VR HWD",
            "Handheld AR (Smartphone)",
            "Handheld AR (Tablet)",
            "Spatial AR (projector based)",
            "Stereoscopic Projection",
            "CAVE",
            "Tablet",
            "Smartphone",
            "Smartwatch",
            "Desktop",
            "Laptop",
            "Projection",
            "Large Display",
            "Tabletop",
        ],
        "devices-reduced": [
            "AR OST HWD",
            "AR VST HWD",
            "VR HWD",
            "Handheld AR (Smartphone)",
            "Handheld AR (Tablet)",
            "Tablet",
            "Smartphone",
            "Desktop",
            "Tabletop",
        ],
        "ar devices": [
            "AR OST HWD",
            "AR VST HWD",
            "VR HWD",
            "Handheld AR (Smartphone)",
            "Handheld AR (Tablet)",
            "Spatial AR (projector based)",
            "Stereoscopic Projection",
            "CAVE",
        ],
        "2D devices": [
            "Tablet",
            "Smartphone",
            "Smartwatch",
            "Desktop",
            "Laptop",
            "Projection",
            "Large Display",
            "Tabletop",
        ],
        "evaluation": [
            "Informative",
            "Usage",
            "Demonstration",
            "Technical Evaluation",
            "Heuristic",
            "No Evaluation",
        ],
        "temporal": [
            "Parallel",
            "Serial",
            "Exclusive"
        ],
        "configuration": [
            "Symmetric Mirror",
            "Asymmetric Mirror",
            "Logical Distribution",
            "Remote Control",
            "Dynamic Lens",
            "Augmented Display",
            "VESAD",
            "Migratory Interface",
        ],
        "relations": [
            "Single User",
            "Multi-user - Individual Component",
            "Multi-user - Shared Component",
        ],
        "scale": [
            "Near",
            "Personal",
            "Social",
            "Public",
        ],
        "dynamics": [
            "Fixed",
            "Semi-Fixed",
            "Flexible",
        ],
        "codependency": [
            "Unidirectional (2D-centric)",
            "Unidirectional (MR-centric)",
            "Bidirectional",
        ],
        "space": [
            "Co-Located",
            "Remote",
        ],
        "mr anchoring": [
            "Component-coupled",
            "Free",
            "Dynamic",
        ]
    }

    Coding_cols = Categories["contribution"] + Categories["devices"] + Categories["evaluation"] + Categories["temporal"] + Categories["configuration"] + Categories["relations"] + Categories["scale"] + Categories["dynamics"] + Categories["codependency"] + Categories["space"] + Categories["mr anchoring"]
