# 01 Query

Contains all information regarding the queries used for our survey.
This folder contains the following files.

## 01 Appendix.pdf
An appendix document describing the query design and the different query instances for all libraries.

## 02 IEEE Query.md
The query used to search within the IEEE Xplore.

## 03 ACM-Wiley Query.md
The query used to search within the ACM DL and Wiley Online Library.

## 04 Springer Query.md
The query used to search within Springer Link.