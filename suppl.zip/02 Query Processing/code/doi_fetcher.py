#!/usr/bin/env python3

from typing import List
import polars as pl
from config import Config
from habanero import Crossref, WorksContainer


def fetch_info_from_doi(path: str) -> List:
    cr = Crossref()

    entries = []
    with open(path, encoding="utf8") as f:
        for line in f:
            doi = line.strip()
            try:
                res = WorksContainer(cr.works(ids=doi))
                entries.append({
                    "year": res.published[0]["date-parts"][0][0],
                    "document title": res.title[0][0] if len(res.subtitle[0]) == 0 else f"{res.title[0][0]}: {res.subtitle[0][0]}",
                    "author": " and ".join([f"{a["family"]}, {a["given"]}" for a in res.author[0]]),
                    "publisher": res.publisher[0],
                    "publication title": res.container_title[0][0],
                    "doi": doi,
                    "pdf link": res.link[0][0]["URL"],
                    "type": res.type[0],
                })
            except:
                print(f"Failed to load: {doi}")

    return entries            


if __name__ == '__main__':
    for name in ["handpicked", "hui-workshop"]:
        pubs = fetch_info_from_doi(f"{Config.PATH_INPUT}/{name}.txt")
        df = pl.DataFrame(pubs)
        df.write_csv(
            file=f"{Config.PATH_PRE}/{name}.csv",
            separator=";",
            quote_style="always"
        )