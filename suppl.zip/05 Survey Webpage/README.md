# Survey Corpus Website

A website presenting the corpus and its coding.
This folder only contains the finished static build. The website is live at https://imldresden.github.io/huis/. 
This project is based on the following code: https://github.com/VisDunneRight/Indy-Survey-Tool. 

## How to Use

1. Open `index.html` in a web browser.
2. Navigate through the webpage as you like.