# Springer Query

## Full Query

```
(
    ( 
        "Hybrid Virtual Environment" OR 
        "Hybrid Interaction" OR 
        "Cross-Device" OR 
        "Cross Device" OR 
        "Cross-Surface" OR 
        "Cross Surface" OR 
        "Multi-Device" OR 
        "Multi Device" OR 
        "Multi-Display" OR	 
        "Multi Display" OR	 
        "Distributed User Interface" OR 
        "Distributed User Interfaces" OR 
        "Transitional Interface" OR 
        "Transitional Interfaces" OR 
        "Cross-Reality" 
    ) AND ( 
        "Augmented Reality" OR 
        "Extended Reality" OR 
        "Mixed Reality" OR 
        "Virtual Reality" 
    ) 
) OR ( 
    "Hybrid User Interface" OR 
    "Hybrid User Interfaces" OR 
    "Complementary Interface" OR 
    "Complementary Interfaces" OR 
    "Augmented Display" OR 
    "Augmented Displays" OR 
    "Cross-Reality" OR 
    "Cross Reality" 
)
```

## Compressed Query

```
( ( "Hybrid Virtual Environment" OR "Hybrid Interaction" OR "Cross-Device" OR "Cross Device" OR "Cross-Surface" OR "Cross Surface" OR "Multi-Device" OR "Multi Device" OR "Multi-Display" OR	 "Multi Display" OR	 "Distributed User Interface" OR "Distributed User Interfaces" OR "Transitional Interface" OR "Transitional Interfaces" OR "Cross-Reality" ) AND ( "Augmented Reality" OR "Extended Reality" OR "Mixed Reality" OR "Virtual Reality" ) ) OR ( "Hybrid User Interface" OR "Hybrid User Interfaces" OR "Complementary Interface" OR "Complementary Interfaces" OR "Augmented Display" OR "Augmented Displays" OR "Cross-Reality" OR "Cross Reality" )
```