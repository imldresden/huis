#!/usr/bin/env python3

import numpy as np
import polars as pl
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from utils import Utils
from configs.general_config import GeneralConfig
from configs.fig_config import FigConfig, FigLayout, VisConfig
from data_handler import DataHandler


def draw_stacked_bar_categories(data: pl.DataFrame, vis_config: VisConfig, title_suffix: str = None, show_percentage: bool = False, fig_layout: FigLayout = None):
    """Draws a stacked bar chart.

    Args:
        data (pl.DataFrame): The data to use.
        vis_config (VisConfig): The config for this figure.
        title_suffix (str, optional): The suffix to add to the filename. Defaults to None.
        show_percentage (bool, optional): Should the y axis be absolut or in percentage?. Defaults to False.
        fig_layout (FigLayout, optional): How should the figure be layouted due to size, margins, and spacing. Defaults to None and with that to default values.
    """
    # region Figure Setup
    if fig_layout is None:
        size = (
            FigConfig.FullWidth,
            FigConfig.Height * 0.3
        )
        fig_layout = FigLayout(
            size=size,
            margin = FigConfig.calc_margin_single(fig_size=size, margin=(.35, .25, .03, .45)),
            spacing = FigConfig.calc_spacing_single(fig_size=size, spacing=(0.125, 0.2))
        )

    fig = plt.figure(
        figsize=fig_layout["size"],
        dpi=FigConfig.Dpi
    )
    gs = GridSpec(
        nrows=1,
        ncols=1,
        figure=fig,
        left=fig_layout["margin"]["left"],
        top=fig_layout["margin"]["top"],
        right=fig_layout["margin"]["right"],
        bottom=fig_layout["margin"]["bottom"],
        wspace=fig_layout["size"][0] * fig_layout["spacing"]["vertical"],
        hspace=fig_layout["size"][1] * fig_layout["spacing"]["horizontal"],
    )
    # endregion

    # change the vis config values if the content should show percentages
    if show_percentage:
        vis_config["yLims"] = [0, 100]
        vis_config["yLabel"] = "Percent"

    # region Figure Content
    df = data
    categories = [c for c in vis_config["categories"] if c in df.columns]

    # sum every column so that it can be stacked
    last_col = categories[0]
    for col in categories[1:]:
        df = df.with_columns((pl.col(col) + pl.col(last_col)).alias(col))
        last_col = col
    # check if those values should be percentage
    if show_percentage:
        for col in categories:
            df = df.with_columns((pl.col(col) * 100 / pl.col(last_col)).alias(col))

    ax = fig.add_subplot(gs[0, 0])
    for col in reversed(categories):
        sns.barplot(
            ax=ax,
            data=df,
            x=vis_config["xColumn"],
            y=col,
            color=vis_config["ColorPalette"][col],
            linewidth=0,
            legend=False,
        )

    ax.set_xlabel(vis_config["xLabel"])
    ax.set_ylabel(vis_config["yLabel"])
    plt.xticks(rotation=90)
    ax.set_xticklabels([l if i % 2 == 0 else "" for (i, l) in enumerate(ax.get_xticklabels())])
    # plt.yscale('log')

    if "yLims" in vis_config:
        ax.set_ylim(
            bottom=vis_config["yLims"][0],
            top=vis_config["yLims"][1]
        )
    if "Title" in vis_config:
        ax.set_title(vis_config["Title"])

    Utils.set_custom_legend(
        fig=fig,
        ax=None,
        keys=categories if "legendColorPalette" not in vis_config else list(vis_config["legendColorPalette"].keys()),
        colors=list(vis_config["ColorPalette"].values()) if "legendColorPalette" not in vis_config else list(vis_config["legendColorPalette"].values()),
        title=vis_config["legendLabel"],
        y_pos=fig_layout["legendYPos"] if "legendYPos" in fig_layout else 1.0,
        patch=True
    )
    # endregion

    # region Saving Fig
    fig.tight_layout()

    for format_str in FigConfig.VisFormats:
        fig.savefig(f"{Utils.gen_filename(vis_config, title_suffix)}.{format_str}")
    plt.close(fig)
    # endregion