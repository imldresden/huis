# Corpus Visualizer

This small projects creates visualizations based on the survey corpus.
All input and output files are the same used for the manuscript: "Hybrid User Interfaces: Past, Present, and Future of Complementary Cross-Device Interaction in Mixed Reality".
However, you can reuse this code however you want.

## Setup

1. Setup the python environment by running the following command within this project/folder: `pip install -r requirements.txt`
2. (Optional) Replace the files in `code/input/` accordingly to your on survey. If using our survey files, export the table `Papers` as a `*.csv` and remove the first two lines.
3. (Optional) Adjust values in each config file in `code/configs/`

## How to Use

1. Make sure that the input files are present.
2. Run `data_handler.py`. This will create a pre-processed input file.
3. Execute the `vis_test_ground.py` or `vis_paper_creation.py` scripts if wished. The later will create the visualizations used (directly or as a basis) for the manuscript.

## Config

### general_config

Defines the paths for the scripts to use.

### data_config

Holds all information regarding the data in the survey corpus.

### figure_config

Defines different values used for creating the visualizations.
More importantly, you can set in `FigureConfig` the output file types (`VisFormats`) and the different figure configurations (`VisConfigs`).