#!/usr/bin/env python3

from pathlib import Path
import polars as pl
import json
from config import Config

ID_FILE_NAME = "lit_index.json"

def combine_to_one() -> pl.DataFrame:
    index = {}

    # Load indicies
    if Path(f"{Config.PATH_OUTPUT}/{ID_FILE_NAME}").is_file():
        with open(f"{Config.PATH_OUTPUT}/{ID_FILE_NAME}") as file:
            index = json.load(file)

    dfs = {
        "acm": pl.read_csv(f"{Config.PATH_PRE}/acm.csv", separator=";"),
        "wiley": pl.read_csv(f"{Config.PATH_PRE}/wiley.csv", separator=";"),
        "ieee": pl.read_csv(f"{Config.PATH_INPUT}/ieee.csv", separator=",", infer_schema_length=200),
        "springer": pl.read_csv(f"{Config.PATH_INPUT}/springer.csv", separator=","),
        "refer-to-hui": pl.read_csv(f"{Config.PATH_PRE}/pop-hui.csv", separator=";"),
        "refer-to-dui": pl.read_csv(f"{Config.PATH_PRE}/pop-dui.csv", separator=";"),
        "refer-to-ad": pl.read_csv(f"{Config.PATH_PRE}/pop-ad.csv", separator=";"),
        "refer-to-ci": pl.read_csv(f"{Config.PATH_PRE}/pop-ci.csv", separator=";"),
        "refer-to-cdt": pl.read_csv(f"{Config.PATH_PRE}/pop-cdt.csv", separator=";"),
        "refer-to-ti": pl.read_csv(f"{Config.PATH_PRE}/pop-ti.csv", separator=";"),
        "refer-to-cr": pl.read_csv(f"{Config.PATH_PRE}/pop-cr.csv", separator=";"),
        "handpicked": pl.read_csv(f"{Config.PATH_PRE}/handpicked.csv", separator=";"),
        "hui-workshop": pl.read_csv(f"{Config.PATH_PRE}/hui-workshop.csv", separator=";"),
        "handpicked_missing_doi": pl.read_csv(f"{Config.PATH_PRE}/handpicked_missing_doi.csv", separator=";"),
    }

    data = {col: [] for col in Config.TARGET_COLS + ["source"]}
    for lib, df in dfs.items():
        # Select the right mapping
        mapping = Config.COL_MAPPING[lib]
        for target, source in mapping.items():
            # Either fill the columns with the correct entry or enter empty values
            if source != "":
                data[target].extend(df.get_column(source).to_list())
            else:
                data[target].extend([None for _ in range(0,df.shape[0])])

        # Also add from which source this entry has come from
        data["source"].extend([lib for _ in range(0,df.shape[0])])

    # Define the index mapping
    def index_mapping(struct: dict) -> pl.Series:
        # Construct the key
        key = f"{struct["source"]} | {struct[Config.TARGET_COLS[1]]} | {struct[Config.TARGET_COLS[5]]}".lower()
        if key not in index:
            index[key] = max(index.values()) + 1

        return index[key]
            
    df = pl.DataFrame(data, strict=False)
    # Reorder the data frame, so that the index are in front
    df = df.select([
        # Set indicies for each entry
        pl.struct([pl.col(Config.TARGET_COLS[1]), pl.col("source"), pl.col(Config.TARGET_COLS[5])]).map_elements(index_mapping, return_dtype=pl.Int32).alias("index"),
        pl.all()
    ])

    # Save the indicies
    with open(f"{Config.PATH_OUTPUT}/{ID_FILE_NAME}","w") as file:
        json.dump(index, file)

    return df


if __name__ == '__main__':
    df = combine_to_one()
    df.write_csv(
        file=f"{Config.PATH_OUTPUT}/literature.csv",
        separator=";",
        quote_style="always"
    )
