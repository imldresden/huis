# IEEE Query

## Full Query

```
(
	(
		(
			"Document Title": "Hybrid Virtual Environment" OR 
			"Document Title": "Hybrid Interface" OR 
			"Document Title": "Cross-Device" OR 
			"Document Title": "Cross Device" OR 
			"Document Title": "Cross-Surface" OR 
			"Document Title": "Cross Surface" OR 
			"Document Title": "Multi-Device" OR 
			"Document Title": "Multi Device" OR 
			"Document Title": "Multi-Display" OR 
			"Document Title": "Multi Display" OR 
			"Document Title": "Distributed User Interface" OR 
			"Document Title": "Distributed User Interfaces" OR 
			"Document Title": "Transitional Interface" OR 
			"Document Title": "Transitional Interfaces"	
		) AND (
			"Document Title": "Augmented Reality" OR 
			"Document Title": "Extended Reality" OR 
			"Document Title": "Mixed Reality" OR 
			"Document Title": "Virtual Reality"
		)
	) OR (
		"Document Title": "Hybrid User Interface" OR 
		"Document Title": "Hybrid User Interfaces" OR 
		"Document Title": "Complementary Interface" OR 
		"Document Title": "Complementary Interfaces" OR 
		"Document Title": "Augmented Display" OR 
		"Document Title": "Augmented Displays" OR 
		"Document Title": "Cross-Reality" OR 
		"Document Title": "Cross Reality"
	)
) 
OR
(
	(
		(
			"Abstract": "Hybrid Virtual Environment" OR 
			"Abstract": "Hybrid Interface" OR 
			"Abstract": "Cross-Device" OR 
			"Abstract": "Cross Device" OR 
			"Abstract": "Cross-Surface" OR 
			"Abstract": "Cross Surface" OR 
			"Abstract": "Multi-Device" OR 
			"Abstract": "Multi Device" OR 
			"Abstract": "Multi-Display" OR 
			"Abstract": "Multi Display" OR 
			"Abstract": "Distributed User Interface" OR 
			"Abstract": "Distributed User Interfaces" OR 
			"Abstract": "Transitional Interface" OR 
			"Abstract": "Transitional Interfaces"	
		) AND (
			"Abstract": "Augmented Reality" OR 
			"Abstract": "Extended Reality" OR 
			"Abstract": "Mixed Reality" OR 
			"Abstract": "Virtual Reality"
		)
	) OR (
		"Abstract": "Hybrid User Interface" OR 
		"Abstract": "Hybrid User Interfaces" OR 
		"Abstract": "Complementary Interface" OR 
		"Abstract": "Complementary Interfaces" OR 
		"Abstract": "Augmented Display" OR 
		"Abstract": "Augmented Displays" OR 
		"Abstract": "Cross-Reality" OR 
		"Abstract": "Cross Reality"
	)
) 
OR
(
	(
		(
			"Author Keywords": "Hybrid Virtual Environment" OR 
			"Author Keywords": "Hybrid Interface" OR 
			"Author Keywords": "Cross-Device" OR 
			"Author Keywords": "Cross Device" OR 
			"Author Keywords": "Cross-Surface" OR 
			"Author Keywords": "Cross Surface" OR 
			"Author Keywords": "Multi-Device" OR 
			"Author Keywords": "Multi Device" OR 
			"Author Keywords": "Multi-Display" OR 
			"Author Keywords": "Multi Display" OR 
			"Author Keywords": "Distributed User Interface" OR 
			"Author Keywords": "Distributed User Interfaces" OR 
			"Author Keywords": "Transitional Interface" OR 
			"Author Keywords": "Transitional Interfaces"	
		) AND (
			"Author Keywords": "Augmented Reality" OR 
			"Author Keywords": "Extended Reality" OR 
			"Author Keywords": "Mixed Reality" OR 
			"Author Keywords": "Virtual Reality"
		)
	) OR (
		"Author Keywords": "Hybrid User Interface" OR 
		"Author Keywords": "Hybrid User Interfaces" OR 
		"Author Keywords": "Complementary Interface" OR 
		"Author Keywords": "Complementary Interfaces" OR 
		"Author Keywords": "Augmented Display" OR 
		"Author Keywords": "Augmented Displays" OR 
		"Author Keywords": "Cross-Reality" OR 
		"Author Keywords": "Cross Reality"
	)
)
```

## Compressed Query

```
( ( ( "Document Title": "Hybrid Virtual Environment" OR "Document Title": "Hybrid Interface" OR "Document Title": "Cross-Device" OR "Document Title": "Cross Device" OR "Document Title": "Cross-Surface" OR "Document Title": "Cross Surface" OR "Document Title": "Multi-Device" OR "Document Title": "Multi Device" OR "Document Title": "Multi-Display" OR "Document Title": "Multi Display" OR "Document Title": "Distributed User Interface" OR "Document Title": "Distributed User Interfaces" OR "Document Title": "Transitional Interface" OR "Document Title": "Transitional Interfaces"	 ) AND ( "Document Title": "Augmented Reality" OR "Document Title": "Extended Reality" OR "Document Title": "Mixed Reality" OR "Document Title": "Virtual Reality" ) ) OR ( "Document Title": "Hybrid User Interface" OR "Document Title": "Hybrid User Interfaces" OR "Document Title": "Complementary Interface" OR "Document Title": "Complementary Interfaces" OR "Document Title": "Augmented Display" OR "Document Title": "Augmented Displays" OR "Document Title": "Cross-Reality" OR "Document Title": "Cross Reality" ) ) OR ( ( ( "Abstract": "Hybrid Virtual Environment" OR "Abstract": "Hybrid Interface" OR "Abstract": "Cross-Device" OR "Abstract": "Cross Device" OR "Abstract": "Cross-Surface" OR "Abstract": "Cross Surface" OR "Abstract": "Multi-Device" OR "Abstract": "Multi Device" OR "Abstract": "Multi-Display" OR "Abstract": "Multi Display" OR "Abstract": "Distributed User Interface" OR "Abstract": "Distributed User Interfaces" OR "Abstract": "Transitional Interface" OR "Abstract": "Transitional Interfaces"	 ) AND ( "Abstract": "Augmented Reality" OR "Abstract": "Extended Reality" OR "Abstract": "Mixed Reality" OR "Abstract": "Virtual Reality" ) ) OR ( "Abstract": "Hybrid User Interface" OR "Abstract": "Hybrid User Interfaces" OR "Abstract": "Complementary Interface" OR "Abstract": "Complementary Interfaces" OR "Abstract": "Augmented Display" OR "Abstract": "Augmented Displays" OR "Abstract": "Cross-Reality" OR "Abstract": "Cross Reality" ) ) OR ( ( ( "Author Keywords": "Hybrid Virtual Environment" OR "Author Keywords": "Hybrid Interface" OR "Author Keywords": "Cross-Device" OR "Author Keywords": "Cross Device" OR "Author Keywords": "Cross-Surface" OR "Author Keywords": "Cross Surface" OR "Author Keywords": "Multi-Device" OR "Author Keywords": "Multi Device" OR "Author Keywords": "Multi-Display" OR "Author Keywords": "Multi Display" OR "Author Keywords": "Distributed User Interface" OR "Author Keywords": "Distributed User Interfaces" OR "Author Keywords": "Transitional Interface" OR "Author Keywords": "Transitional Interfaces"	 ) AND ( "Author Keywords": "Augmented Reality" OR "Author Keywords": "Extended Reality" OR "Author Keywords": "Mixed Reality" OR "Author Keywords": "Virtual Reality" ) ) OR ( "Author Keywords": "Hybrid User Interface" OR "Author Keywords": "Hybrid User Interfaces" OR "Author Keywords": "Complementary Interface" OR "Author Keywords": "Complementary Interfaces" OR "Author Keywords": "Augmented Display" OR "Author Keywords": "Augmented Displays" OR "Author Keywords": "Cross-Reality" OR "Author Keywords": "Cross Reality" ) )
```