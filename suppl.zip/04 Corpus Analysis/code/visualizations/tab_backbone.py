#!/usr/bin/env python3

from typing import List
import polars as pl

from configs.data_config import DataConfig
from configs.general_config import GeneralConfig


class DataHandler:
    # region Data Clean Up
    @staticmethod
    def clean_up_data(path: str) -> pl.DataFrame:
        """Takes the files given at @path and prepares it for further use in this project.

        Args:
            path (str): the path to the file to use as input.

        Returns:
            pl.DataFrame: the cleaned up data.
        """
        # load the file
        df = pl.read_csv(
            source=path,
            has_header=True,
            infer_schema_length=2000,
        )

        # remove unnecessary columns
        df = df.drop(DataConfig.Drop_cols)

        df = df.with_columns(pl.col("content duplicate (e.g. demo) to").replace_strict({None: False}, default=True, return_dtype=pl.Boolean))
        # replace every value accordingly
        for col in df.columns:
            try:
                df = df.with_columns(
                        pl.col(col).replace_strict(
                            {
                                "x": True, 
                                "(x)": True, 
                                "-": True, 
                                "?": False,
                                None: False, 
                            }, 
                            return_dtype=pl.Boolean
                        )
                )
            except:
                print(col)
                pass
        
        df = df.with_columns(
            pl.col("Eligible").replace("Kicked", "Removed in Screening")
        )

        # save the file for further use
        df.write_csv(
            file=f"{GeneralConfig.PATH_PRE}/cleaned_data.csv",
            separator=";",
            quote_style="always",
        )
        return df
    # endregion

    # region Data Loader
    @staticmethod
    def load_data() -> pl.DataFrame:
        """Loads the complete dataset.

        Returns:
            pl.DataFrame: the loaded data.
        """
        df = pl.read_csv(
            source=f"{GeneralConfig.PATH_PRE}/cleaned_data.csv",
            has_header=True,
            separator=";"
        )        
            
        # remove years not in range
        df = df.filter(pl.col("year").is_in(DataConfig.Categories["year"]))

        return df
    
    @staticmethod
    def load_data_eligible() -> pl.DataFrame:
        """Loads the dataset, but only outputs rows that have the 'Eligible' value equal to 'Yes'.

        Returns:
            pl.DataFrame: the loaded data.
        """
        df = DataHandler.load_data()

        # prepare the dataset for the specific use
        df = df.filter(
            pl.col("Eligible") == "Yes"
        )
        df = df.drop(DataConfig.Categories["eligibility check"])

        return df
    
    @staticmethod
    def load_data_not_eligible() -> pl.DataFrame:
        """Loads the dataset, but only outputs rows that have the 'Eligible' value equal to 'No' or 'Duplicate'.

        Returns:
            pl.DataFrame: the loaded data.
        """
        df = DataHandler.load_data()

        # prepare the dataset for the specific use
        df = df.filter(
            (pl.col("Eligible") == "No") | (pl.col("Eligible") == "Duplicate")
        )
        df = df.drop(DataConfig.Coding_cols)

        return df
    # endregion

    # region Pre-processed Data
    @staticmethod
    def get_grouped_by(group_by: str, data: pl.DataFrame) -> pl.DataFrame:
        """Returns a new view on the given dataframe that is grouped by the given value.

        Args:
            group_by (str): the column that should be used to group by.
            data (pl.DataFrame): the dataframe to group by.

        Returns:
            pl.DataFrame: the grouped dataframe.
        """
        # check if by is really a column
        if group_by not in data.columns:
            return None

        # remove unnecessary columns
        drop = DataConfig.Str_cols
        if group_by in DataConfig.Str_cols:
            drop.remove(group_by)
        df = data.drop(drop)

        # group them by ??
        df = df.group_by(pl.col(group_by)).agg(pl.all())
        # count for every by ?? and boolean column the number of "true"
        for col in df.columns:
            if col in [group_by, "Index"]:
                continue

            df = df.with_columns(
                pl.col(col).list.count_matches(True)
            )
        # count how many paper in general per by ??
        df = df.with_columns(
            pl.col("Index").list.len()
        )
        # cast to the right type
        df = df.select([
            pl.col(group_by),
            pl.all().exclude(group_by).cast(pl.Int64)
        ])

        # sort the result
        df = df.sort(group_by)
        
        return df
    
    @staticmethod
    def get_unique_values_grouped_by(group_by: str, split_by: str, data: pl.DataFrame) -> pl.DataFrame:
        """Generates a view on the given dataframe that has as columns all unique instances of the @split_by column and is grouped by the given additional column.

        Args:
            group_by (str): the column to group the data by.
            split_by (str): the column that unique values should be used as new columns.
            data (pl.DataFrame): the dataframe to alter.

        Returns:
            pl.DataFrame: the new dataframe with the columns: 'grouped_by' and all unique values of 'split_by'.
        """
        # only select the columns needed
        df = data.group_by(group_by).agg(pl.all())
        # add new columns based on the eligibility codes
        for v in data[split_by].unique():
            df = df.with_columns(pl.col(split_by).list.count_matches(v).alias(v))
        # remove the columns that are no longer needed
        df = df.select([group_by] + data[split_by].unique().to_list())
        # cast to the right type
        df = df.select([
            pl.col(group_by),
            pl.all().exclude(group_by).cast(pl.Int64)
        ])

        # sort the result
        df = df.sort(group_by)

        return df
    
    @staticmethod
    def get_split_by_unique_values(split_by: str, data: pl.DataFrame) -> pl.DataFrame:
        # only select the columns needed
        df = data
        # add new columns based on the eligibility codes
        for v in data[split_by].unique():
            df = df.with_columns(pl.when(pl.col(split_by) == v).then(True).otherwise(False).alias(str(v)))
        # remove the columns that are no longer needed
        df = df.select(pl.exclude(split_by))

        return df
    
    @staticmethod
    def get_combine_columns_to(columns: List[str], to: str, data:pl.DataFrame) -> pl.DataFrame:
        """Combines different @columns into one (@to) column while grouping the other columns accordingly.

        Args:
            columns (List[str]): the list of columns to combine to one.
            to (str): how the new combined column should be named.
            data (pl.DataFrame): the dataframe to alter.

        Returns:
            pl.DataFrame: the new dataframe without the columns in @column but with the new one (@to).
        """
        out_df = pl.DataFrame()
        for col in columns:
            tmp_df = data.filter(pl.col(col) == True)
            tmp_df = tmp_df.group_by(col).agg(pl.all())     
            for c in tmp_df.columns:
                if c in columns:
                    continue

                if c == "Index":
                    tmp_df = tmp_df.with_columns(
                        pl.col(c).list.len()
                    )
                else:   
                    tmp_df = tmp_df.with_columns(
                        pl.col(c).list.count_matches(True)
                    )
            tmp_df = tmp_df.select(pl.exclude(columns))
            tmp_df = tmp_df.with_columns(pl.lit(col).alias(to))

            if out_df.is_empty():
                out_df = tmp_df
            else:
                out_df = pl.concat([out_df, tmp_df])
        
        return out_df
    
    @staticmethod
    def get_count(data: pl.DataFrame, pivoted: bool = False) -> pl.DataFrame:
        # group everything
        df = data.unpivot().group_by("variable").agg(pl.all())
        # add the column counts
        df = df.with_columns(pl.col("value").list.count_matches(True).alias("count"))
            # remove the unnecessary columns
        df = df.drop("value")

        if pivoted:
            # pivot the table again
            df = df.with_columns(pl.lit(0).alias("index"))
            df = df.pivot(
                on="variable",
                index="index",
                values="count"
            )
            # remove the unnecessary columns
            df = df.drop("index")

        return df
    
    @staticmethod
    def get_percentage(data: pl.DataFrame, pivoted: bool = False) -> pl.DataFrame:
        # group everything
        df = data.unpivot().group_by("variable").agg(pl.all())
        # add the column percentage
        df = df.with_columns((pl.col("value").list.count_matches(True) * 100 / data.shape[0]).alias("percentage"))
            # remove the unnecessary columns
        df = df.drop("value")

        if pivoted:
            # pivot the table again
            df = df.with_columns(pl.lit(0).alias("index"))
            df = df.pivot(
                on="variable",
                index="index",
                values="percentage"
            )
            # remove the unnecessary columns
            df = df.drop("index")

        return df
    # endregion

    # region Further Data Methods
    @staticmethod
    def add_missing_years(data: pl.DataFrame) -> pl.DataFrame:
        """Adds missing years to a dataframe that was grouped by years beforehand.

        Args:
            data (pl.DataFrame): the dataframe to extend.

        Returns:
            pl.DataFrame: the extended dataframe.
        """
        # get the missing years by checking the range
        missing_years = [y for y in DataConfig.Categories["year"] if y not in data["year"].unique()]
        # generate the dataset to add
        tmp = {"year": missing_years}
        tmp.update({k: [0 for _ in range(0, len(missing_years))] for k in data.columns if k != "year"})
        # extend the dataframe by the missing data
        data = data.extend(pl.DataFrame(tmp).cast(pl.Int64))

        return data
    
    @staticmethod
    def add_missing_values(column: str, data: pl.DataFrame) -> pl.DataFrame:
        # get the missing years by checking the range
        missing_values = [y for y in DataConfig.Categories[column] if y not in data[column].unique()]
        # generate the dataset to add
        tmp = {k: 
                missing_values if k == column else [0 for _ in range(0, len(missing_values))] 
                for k in data.columns}
        tmp_df = pl.DataFrame(tmp)
        for c in tmp_df.columns:
            if c == column:
                continue

            tmp_df = tmp_df.with_columns(pl.col(c).cast(pl.Int64))
        # extend the dataframe by the missing data
        data = data.extend(tmp_df)

        return data
    # endregion

if __name__ == '__main__':
    DataHandler.clean_up_data(
        path=f"{GeneralConfig.PATH_INPUT}/coded papers.csv"
    )
