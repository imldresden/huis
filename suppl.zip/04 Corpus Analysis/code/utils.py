from typing import List

from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from configs.general_config import GeneralConfig
from configs.fig_config import FigConfig, VisConfig


class Utils:    
    MAIN_PATH = GeneralConfig.VIS_PATH

    @staticmethod
    def gen_filename(vis_config: VisConfig, title_suffix: str) -> str:
        return f"{Utils.MAIN_PATH}/{vis_config['FileName']}{" _" if title_suffix != None else ""}{title_suffix}"

    @staticmethod
    def set_legend_from_vis(fig: plt.Figure, ax: plt.Axes, y_pos: float = 1.0, label_on_fig: bool = True, special_legend: bool = False):
        obj = fig if label_on_fig else ax

        if not special_legend:
            handles, labels = ax.get_legend_handles_labels()
            if type(handles[0]) is Line2D:
                for h in handles:
                    h._linewidth = FigConfig.LineWidth
        else:
            handles = ax.get_legend().legendHandles
            labels = [t._text for t in ax.get_legend().texts]

        obj.legend(
            handles,
            labels,
            loc="upper center",
            bbox_to_anchor=(0.5, y_pos),
            ncol=5,
            framealpha=0.95,
            edgecolor="#000000"
        )

    @staticmethod
    def set_custom_legend(fig: plt.Figure, ax: plt.Axes, keys: List[str], colors: List[str], title: str = None, patch: bool = False, label_on_fig: bool = True, y_pos: float = 1.0, legend_box_line_width: float = 0.4):
        obj = fig if label_on_fig else ax

        lw = FigConfig.LineWidth

        custom_lines = [Line2D(xdata=(0, 1), ydata=(0, 0), color="#ffffff", linewidth=lw)] if title is not None else []
        if patch:
            custom_lines += [Patch(facecolor=c, edgecolor=c) for c in colors]
        else:
            custom_lines += [Line2D(xdata=(0, 1), ydata=(0, 0), color=c, linewidth=lw) for c in colors]

        leg = obj.legend(
            custom_lines,
            [title + ":"] + keys if title is not None else keys,
            loc="upper center",
            bbox_to_anchor=(0.5, y_pos),
            ncol=len(keys) + 1 if title is not None else len(keys),
            framealpha=0.95,
            edgecolor="#000000",
            columnspacing=1.5,
            handletextpad=0.25,
        )
        leg.get_frame().set_linewidth(legend_box_line_width)

        if title is not None:
            for vpack in leg._legend_handle_box.get_children()[:1]:
                for hpack in vpack.get_children():
                    hpack.get_children()[0].set_width(0)

    @staticmethod
    def add_costume_xlabel(fig: plt.Figure, label: str, y_pos: float = 0.0):
        fig.text(
            x=0.5,
            y=y_pos,
            s=label,
            horizontalalignment="center",
            verticalalignment="bottom",
            fontsize=FigConfig.RC_FONTS["axes"]["label"],
            fontweight="bold"
        )
