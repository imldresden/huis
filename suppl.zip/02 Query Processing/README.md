# Query Result Processor

This small projects allows you to pre-process search query results from different digital libraries.
All input and output files are the same used for the manuscript: "Hybrid User Interfaces: Past, Present, and Future of Complementary Cross-Device Interaction in Mixed Reality".
However, you can reuse this code however you want.

## Setup

1. Setup the python environment by running the following command within this project/folder: `pip install -r requirements.txt`
2. (Optional) Conduct the search queries yourself and replace the files in `input/` accordingly. This includes search in the ACM DL, IEEE Xplore, Wiley Online Library, Springer Link, Google Scholar search through "[Publish or Perish](https://harzing.com/resources/publish-or-perish)", and a list of handpicked DOIs.
3. Adjust values in `config.py` (see [Config](###Config))

## How to Use

1. Make sure that all necessary input files are present. 
2. Run `doi_fetcher.py`. This will fetch the correct publications (through [CrossRef](https://www.crossref.org/)) based on the DOIs given in `input/handpicked.txt`.
3. (Optional) Check the output of the previous command. If DOIs could not be loaded ("Failed to load: [...]") add those entries manually to a file named `input/handpicked_missing_doi.bib`.
4. Run `converter.py`. This will pre-process all `*.bib` files into `*.csv` files.
6. Run `corpus_processor.py` to combine all individual search queries into one file.

## Additional Infos

### Config

In the config file, you can set different values like the paths.
You can also set the output format (`TARGET_COLS`) and how the mapping (`COL_MAPPING`) between the different input files to the output format should look like.

### Final Output

The `corpus_processor.py` will output two files: `literature.csv` and `lit_index.json`.
The former contains all publication of the conducted searches, each with an unique identifier.
The latter stores the persistent mapping between the publications and the unique identifiers of the former file.