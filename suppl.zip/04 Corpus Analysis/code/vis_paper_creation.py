#!/usr/bin/env python3

import seaborn as sns
import matplotlib.pyplot as plt

from configs.data_config import DataConfig
from visualizations.tab_backbone import draw_heatmap, draw_heatmap_row_wise
from visualizations.correlation_plot import draw_correlation
from visualizations.single_stacked_bar import draw_single_stack
from visualizations.stacked_bar_chart import draw_stacked_bar_categories
from utils import Utils
from configs.general_config import GeneralConfig
from configs.fig_config import FigConfig, VisConfig, FigLayout
from data_handler import DataHandler


if __name__ == '__main__':
    Utils.MAIN_PATH = GeneralConfig.PAPER_PATH

    eligible_data = DataHandler.load_data_eligible()
    not_eligible_data = DataHandler.load_data_not_eligible()
    complete_data = DataHandler.load_data()

    FigConfig.set_rc_plot_values()

    with sns.axes_style(style=FigConfig.SnsStyle, rc=FigConfig.RC_UPDATE):
        # figures for eligibility criteria
        vis_config = FigConfig.VisConfigs["eligible - year"].copy()
        
        df = DataHandler.add_missing_years(
                DataHandler.get_unique_values_grouped_by(
                    group_by="year", 
                    split_by="Eligible", 
                    data=complete_data
                )
            )
        df = df.rename({"Yes": "Yes", "No": "No (Eligible)", "Removed in Screening": "No (Screening)"})

        size = (FigConfig.ColumnWidth, FigConfig.Height * .2)
        draw_stacked_bar_categories(
            data=df, 
            vis_config=vis_config, 
            title_suffix="Eligible",
            show_percentage=False,
            fig_layout=FigLayout(
                size=size,
                margin = FigConfig.calc_margin_single(fig_size=size, margin=(.36, .22, .03, .4)),
                spacing = FigConfig.calc_spacing_single(fig_size=size, spacing=(0.125, 0.2)),
                legendYPos=1.0225,
            )
        )

    another_rc = {
        "font.family": ["Open Sans", "sans-serif"],
        "font.size": 5,
        "xtick.labelsize": 6,
        "ytick.labelsize": 6,
    }
    plt.rcParams.update(another_rc)
    with sns.axes_style(style=FigConfig.SnsStyle, rc=another_rc):        
        for key in ["taxonomy - configuration", "mr device - 2d device"]:
            vis_config = FigConfig.VisConfigs[f"{key} (heatmap)"]

            draw_heatmap_row_wise(
                data=DataHandler.get_combine_columns_to(
                    columns=DataConfig.Categories[vis_config["yColumn"]],
                    to=vis_config["yColumn"],
                    data=eligible_data),
                vis_config=vis_config,
                title_suffix="Eligible_row-wise",
                with_index=True
            )   

        for key in ["contribution", "evaluation"]:
            vis_config = FigConfig.VisConfigs[f"{key} - year (heatmap)"]
            
            size = (FigConfig.FullWidth, FigConfig.Height * 0.5)
            draw_heatmap_row_wise(
                data=DataHandler.get_grouped_by(
                    group_by="year", 
                    data=eligible_data),
                vis_config=vis_config,
                title_suffix="Eligible_row-wise",                
                fig_layout = FigLayout(
                    size=size,
                    margin = FigConfig.calc_margin_single(fig_size=size, margin=(.35, 1.35, .6, .01)),                
                    spacing = FigConfig.calc_spacing_single(fig_size=size, spacing=(0.125, 0.2))
                )
            )

        
        vis_config = FigConfig.VisConfigs[f"year - devices (heatmap)"]        
        draw_heatmap(
            data=DataHandler.get_combine_columns_to(
                columns=DataConfig.Categories[vis_config["yColumn"]],
                to=vis_config["yColumn"],
                data=DataHandler.get_split_by_unique_values(
                    split_by="year",
                    data=eligible_data)),
            vis_config=vis_config,
            title_suffix="Eligible",
        )
