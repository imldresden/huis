#!/usr/bin/env python3

import numpy as np
import polars as pl
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from utils import Utils
from configs.general_config import GeneralConfig
from configs.fig_config import FigConfig, FigLayout, VisConfig
from data_handler import DataHandler


def draw_correlation(data: pl.DataFrame, vis_config: VisConfig, title_suffix: str = None, fig_layout: 
    FigLayout = None):
    """Draws a correlation plot (adjecency matrix).

    Args:
        data (pl.DataFrame): The data to use.
        vis_config (VisConfig): The config for this figure.
        title_suffix (str, optional): The suffix to add to the filename. Defaults to None.
        fig_layout (FigLayout, optional): How should the figure be layouted due to size, margins, and spacing. Defaults to None and with that to default values.
    """
    # region Figure Setup
    if fig_layout is None:
        size = (
            FigConfig.ColumnWidth,
            FigConfig.Height * 0.3
        )
        fig_layout = FigLayout(
            size=size,
            margin = FigConfig.calc_margin_single(margin=(.2, .03, .03, .2)),                
            spacing = FigConfig.calc_spacing_single(fig_size=size, spacing=(0.125, 0.2))
        )

    fig = plt.figure(
        figsize=fig_layout["size"],
        dpi=FigConfig.Dpi
    )
    gs = GridSpec(
        nrows=1,
        ncols=1,
        figure=fig,
        left=fig_layout["margin"]["left"],
        top=fig_layout["margin"]["top"],
        right=fig_layout["margin"]["right"],
        bottom=fig_layout["margin"]["bottom"],
        wspace=fig_layout["size"][0] * fig_layout["spacing"]["vertical"],
        hspace=fig_layout["size"][1] * fig_layout["spacing"]["horizontal"],
    )
    # endregion
    
    # region Figure Content
    df = data
    categories = [c for c in vis_config["categories"] if c in df.columns]
    df = df.select(categories)
    df = df.corr()

    mask = np.triu(np.ones_like(df, dtype=bool))

    ax = fig.add_subplot(gs[0, 0])
    sns.heatmap(
        ax=ax,
        data=df,
        mask=mask,
        square=True,
        center=0,
        linewidths=.05,
        annot=True,
    )

    angle = 30

    # ax.set_xticks(range(0, df.shape[0]))
    ax.set_xticklabels(df.columns)
    # ax.set_xticklabels(df.columns[:df.shape[0] - 1] + [""])
    plt.xticks(rotation=angle, ha='right')
    # ax.set_yticks(range(0, df.shape[0]))
    ax.set_yticklabels(df.columns)
    # ax.set_yticklabels([""] + df.columns[1:])
    plt.yticks(rotation=angle, va='top')

    ax.grid(False)

    if "Title" in vis_config:
        ax.set_title(vis_config["Title"])
    # endregion

    # region Saving Fig
    fig.tight_layout()

    for format_str in FigConfig.VisFormats:
        fig.savefig(f"{Utils.gen_filename(vis_config, title_suffix)}.{format_str}")
    plt.close(fig)
    # endregion