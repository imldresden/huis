#!/usr/bin/env python3

import re
from typing import List
import polars as pl
from config import Config

# Parts taken from here: https://github.com/fluffels/bibtex-csv
def read_bib(path: str, ) -> List: 
    entries = []
    with open(path, encoding="utf-8") as f:
        entry = None
        for line in f:
            # Check if a new entry started
            if (re.match('^@', line.strip())):
                # Create a new one if the old is already filled
                if entry != {}:
                    if entry is not None:
                        entries.append(entry)
                    entry = {
                        # Get the item type
                        "item type": line.split("{")[0][1:]
                    }
            # Check if this is an url
            elif (re.match('url', line.strip())):
                value, = re.findall('\{(\S+)\}', line)
                entry["url"] = value
            # Check if this is a property
            elif (re.search('=', line.strip())):
                # Get the key and value and save them
                key, value = [v.strip(" {},\n\t") for v in line.split("=", maxsplit=1)]
                entry[key] = value

        entries.append(entry)

    return entries


if __name__ == '__main__':
    for name in ["acm", "wiley", "pop-hui", "pop-dui", "pop-cdt", "pop-ad", "pop-ci", "pop-ti", "pop-cr", "handpicked_missing_doi"]:
        print(f"Converting {name}.bib")
        bib = read_bib(f"{Config.PATH_INPUT}/{name}.bib")
        df = pl.DataFrame(bib)
        df.write_csv(
            file=f"{Config.PATH_PRE}/{name}.csv", 
            separator=";",
            quote_style="always",
        )
