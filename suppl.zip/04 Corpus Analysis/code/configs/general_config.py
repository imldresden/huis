#!/usr/bin/env python3

import os


class GeneralConfig:
    # Paths
    PATH_INPUT = "input"
    PATH_OUTPUT = "output"
    PATH_PRE = "pre-processed"

    VIS_FOLDER = "vis"
    PAPER_FOLDER = "paper"

    VIS_PATH = f"{PATH_OUTPUT}/{VIS_FOLDER}"
    PAPER_PATH = f"{PATH_OUTPUT}/{PAPER_FOLDER}"


os.makedirs(GeneralConfig.PATH_INPUT, exist_ok=True)
os.makedirs(GeneralConfig.PATH_OUTPUT, exist_ok=True)
os.makedirs(GeneralConfig.PATH_PRE, exist_ok=True)

os.makedirs(f"{GeneralConfig.VIS_PATH}", exist_ok=True)
os.makedirs(f"{GeneralConfig.PAPER_PATH}", exist_ok=True)