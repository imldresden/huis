#!/usr/bin/env python3

import polars as pl

from configs.general_config import GeneralConfig
from configs.data_config import DataConfig
from data_handler import DataHandler


class StatsCalc:
    @staticmethod
    def descriptive_all(data: pl.DataFrame, name_addition: str = "", save: bool = True) -> pl.DataFrame:
        count = data.shape[0]

        # count every occurance in every column
        out_df = data.unpivot().group_by(pl.all()).len("count")
        # only check for the True values
        out_df = out_df.filter(pl.col("value") == "true")
        # add percentage values
        out_df = out_df.with_columns((pl.col("count") * 100 / count).alias("perc"))
        # remove the unnecessary column
        out_df = out_df.drop("value")

        if save:
            out_df.write_csv(
                file=f"{GeneralConfig.STATS_PATH}/all{"-" if name_addition != "" else ""}{name_addition}.csv",
                separator=";",
                quote_style="always",
            )

        return out_df    


if __name__ == '__main__':
    # eligible_data = DataProcessing.load_data_eligible()
    # StatsCalc.descriptive_all(data=eligible_data, name_addition="eligible")
    # StatsCalc.descriptive_per_year(data=eligible_data, name_addition="eligible")

    # not_eligible_data = DataProcessing.load_data_not_eligible()
    # StatsCalc.descriptive_all(data=not_eligible_data, name_addition="not_eligible")
    # StatsCalc.descriptive_per_year(data=not_eligible_data, name_addition="not_eligible")

    # complete_data = DataHandler.load_data()
    # StatsCalc.descriptive_pure_eligible(data=complete_data, name_addition="eligiblity_check")
    pass
