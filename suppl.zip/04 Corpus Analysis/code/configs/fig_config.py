#!/usr/bin/env python3

import os
from typing import TypedDict, List, Tuple
from matplotlib import pyplot as plt

from configs.data_config import DataConfig


# region Color Definitions
# see: https://colorbrewer2.org/#type=sequential&scheme=BuGn&n=3
COLOR_BREWER = {
    "qualitative-1": ['#7fc97f','#beaed4','#fdc086','#ffff99','#386cb0','#f0027f','#bf5b17','#666666'],
    "qualitative-2": ['#1b9e77','#d95f02','#7570b3','#e7298a','#66a61e','#e6ab02','#a6761d','#666666'],
    "qualitative-3": ['#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928'],
    "qualitative-4": ['#fbb4ae','#b3cde3','#ccebc5','#decbe4','#fed9a6','#ffffcc','#e5d8bd','#fddaec','#f2f2f2'],
    "qualitative-5": ['#b3e2cd','#fdcdac','#cbd5e8','#f4cae4','#e6f5c9','#fff2ae','#f1e2cc','#cccccc'],
    "qualitative-6": ['#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','#ffff33','#a65628','#f781bf','#999999'],
    "qualitative-7": ['#66c2a5','#fc8d62','#8da0cb','#e78ac3','#a6d854','#ffd92f','#e5c494','#b3b3b3'],
    "qualitative-8": ['#8dd3c7','#ffffb3','#bebada','#fb8072','#80b1d3','#fdb462','#b3de69','#fccde5','#d9d9d9','#bc80bd','#ccebc5','#ffed6f'],
    "diverging-1": ['#543005','#8c510a','#bf812d','#dfc27d','#f6e8c3','#f5f5f5','#c7eae5','#80cdc1','#35978f','#01665e','#003c30'],
    "diverging-2": ['#8e0152','#c51b7d','#de77ae','#f1b6da','#fde0ef','#f7f7f7','#e6f5d0','#b8e186','#7fbc41','#4d9221','#276419'],
    "diverging-3": ['#40004b','#762a83','#9970ab','#c2a5cf','#e7d4e8','#f7f7f7','#d9f0d3','#a6dba0','#5aae61','#1b7837','#00441b'],
    "diverging-4": ['#7f3b08','#b35806','#e08214','#fdb863','#fee0b6','#f7f7f7','#d8daeb','#b2abd2','#8073ac','#542788','#2d004b'],
    "diverging-5": ['#67001f','#b2182b','#d6604d','#f4a582','#fddbc7','#f7f7f7','#d1e5f0','#92c5de','#4393c3','#2166ac','#053061'],
    "diverging-6": ['#67001f','#b2182b','#d6604d','#f4a582','#fddbc7','#ffffff','#e0e0e0','#bababa','#878787','#4d4d4d','#1a1a1a'],
    "diverging-7": ['#a50026','#d73027','#f46d43','#fdae61','#fee090','#ffffbf','#e0f3f8','#abd9e9','#74add1','#4575b4','#313695'],
    "diverging-8": ['#a50026','#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850','#006837'],
    "diverging-9": ['#9e0142','#d53e4f','#f46d43','#fdae61','#fee08b','#ffffbf','#e6f598','#abdda4','#66c2a5','#3288bd','#5e4fa2'],
    # red
    "sequential-1-1": ['#fff5f0','#fee0d2','#fcbba1','#fc9272','#fb6a4a','#ef3b2c','#cb181d','#a50f15','#67000d'],
    # blue
    "sequential-1-2": ['#f7fbff','#deebf7','#c6dbef','#9ecae1','#6baed6','#4292c6','#2171b5','#08519c','#08306b'],
    # orange
    "sequential-1-3": ['#fff5eb','#fee6ce','#fdd0a2','#fdae6b','#fd8d3c','#f16913','#d94801','#a63603','#7f2704'],
    # green
    "sequential-1-4": ['#f7fcf5','#e5f5e0','#c7e9c0','#a1d99b','#74c476','#41ab5d','#238b45','#006d2c','#00441b'],
    # purple
    "sequential-1-5": ['#fcfbfd','#efedf5','#dadaeb','#bcbddc','#9e9ac8','#807dba','#6a51a3','#54278f','#3f007d'],
    # black
    "sequential-1-6": ['#ffffff','#f0f0f0','#d9d9d9','#bdbdbd','#969696','#737373','#525252','#252525','#000000'],
    "sequential-green-blue": ['#f7fcfd','#e5f5f9','#ccece6','#99d8c9','#66c2a4','#41ae76','#238b45','#006d2c','#00441b'],
    "sequential-purple-blue": ['#f7fcfd','#e0ecf4','#bfd3e6','#9ebcda','#8c96c6','#8c6bb1','#88419d','#810f7c','#4d004b'],
    "sequential-blue-green": ['#f7fcf0','#e0f3db','#ccebc5','#a8ddb5','#7bccc4','#4eb3d3','#2b8cbe','#0868ac','#084081'],
    "sequential-red-orange": ['#fff7ec','#fee8c8','#fdd49e','#fdbb84','#fc8d59','#ef6548','#d7301f','#b30000','#7f0000'],
    "sequential-blue-grey": ['#fff7fb','#ece7f2','#d0d1e6','#a6bddb','#74a9cf','#3690c0','#0570b0','#045a8d','#023858'],
    "sequential-green-grey": ['#fff7fb','#ece2f0','#d0d1e6','#a6bddb','#67a9cf','#3690c0','#02818a','#016c59','#014636'],
    "sequential-red-pink": ['#f7f4f9','#e7e1ef','#d4b9da','#c994c7','#df65b0','#e7298a','#ce1256','#980043','#67001f'],
    "sequential-purple-pink": ['#fff7f3','#fde0dd','#fcc5c0','#fa9fb5','#f768a1','#dd3497','#ae017e','#7a0177','#49006a'],
    "sequential-green-yellow": ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529'],
    "sequential-blue-yellow": ['#ffffd9','#edf8b1','#c7e9b4','#7fcdbb','#41b6c4','#1d91c0','#225ea8','#253494','#081d58'],
    "sequential-brown-yellow": ['#ffffe5','#fff7bc','#fee391','#fec44f','#fe9929','#ec7014','#cc4c02','#993404','#662506'],
    "sequential-red-yellow": ['#ffffcc','#ffeda0','#fed976','#feb24c','#fd8d3c','#fc4e2a','#e31a1c','#bd0026','#800026'],
}

COLOR_PALETTES = {
    # see https://coolors.co/246eb9-e23c12-72b01d-a94c93-272727 and https://www.learnui.design/tools/data-color-picker.html#single
    "azul": [ "#246eb9", "#3082c2", "#4595ca", "#5ea8d1", "#7bbbd7", "#98ccde", "#b7dee7", "#d7eff1", "#f7ffff" ],
    "chili red": [ "#e23c12", "#e65f25", "#e97a3a", "#ec9353", "#efa96e", "#f2bf8c", "#f5d3ac", "#fae7ce", "#fffaf2" ],
    "apple green": [ "#72b01d", "#86ba3e", "#99c358", "#abcd71", "#bcd78a", "#cde1a3", "#ddebbc", "#ecf5d5", "#fbffef" ],
    "fandango": [ "#a94c93", "#b363a2", "#be79b0", "#c88ebe", "#d3a3cc", "#ddb9d9", "#e8cee6", "#f3e3f3", "#fff9ff" ],
    "raisin black": [ "#272727", "#3e3e3e", "#565656", "#6f6f6f", "#8a8a8a", "#a5a5a5", "#c1c1c1", "#dedede", "#fcfcfc" ],
}
# endregion Color Definitions

class Margin(TypedDict):
    left: float
    top: float
    right: float
    bottom: float


class Spacing(TypedDict):
    vertical: float
    horizontal: float


class FigLayout(TypedDict):
    size: Tuple[float, float]
    margin: Margin
    spacing: Spacing


class VisConfig(TypedDict):
    Title: str
    ColorPalette: dict
    # y Axis
    yLims: List
    yTicks: List
    yTickLabels: List
    yLabel: str
    # x Axis
    xLims: List
    xTicks: List
    xTickLabels: List
    xLabel: str
    # data selections
    xColumn: str
    yColumn: str
    categories: List
    # legend
    legendLabel: str
    legendColorPalette: dict
    # saving
    FileName: str


class FigConfig:
    Dpi = 300
    # See: https://matplotlib.org/stable/gallery/subplots_axes_and_figures/figure_size_units.html
    cm = 1 / 2.54  # centimeters in inches
    # ACM
    FullWidth = 17.78 * cm
    ColumnWidth = 8.47 * cm
    Height = 23.35 * cm

    Absolute = True

    VisFormats = [
        "jpg",
        "pdf",
    ]
    SnsStyle = "whitegrid"

    # See: https://matplotlib.org/stable/api/matplotlib_configuration_api.html#matplotlib.rcParams
    # For fonts: be vary of https://stackoverflow.com/questions/26085867/matplotlib-font-not-found
    RC_UPDATE = {
        # >>> Controls the default font
        "font.family": ["Open Sans", "sans-serif"],
        # "font.sans-serif": ["Open Sans", "Comic Sans"],
        "font.size": 6,
        # >>> Controls the axis label
        "axes.titlesize": 6,
        "axes.titleweight": "bold",
        # >>> Controls the axis ticks
        "axes.labelsize": 6,
        "axes.labelweight": "normal",
        # >>> Controls the X axis
        "xtick.labelsize": 7,
        "xtick.major.pad": 0,
        "xtick.minor.pad": 0,
        # >>> Controls the Y axis
        "ytick.labelsize": 7,
        "ytick.major.pad": 0,
        "ytick.minor.pad": 0,
        # >>> Controls the legend
        "legend.fontsize": 7,
        # >>> Controls the general title
        "figure.titlesize": 7,
        "figure.titleweight": "bold",
        # >>> Controls the grid lines
        "grid.linewidth": 0.4,
    }

    LineWidth = 1
    ylimFactor = 0.2

    @staticmethod
    def calc_margin_complete(margin: float, fig_size: Tuple[float, float] | None = None) -> Margin:
        """Generates the margin of a figure, based on a single value. If @fig_size is give, it will calculate the absolute values within the figure size. 

        Args:
            margin (float): the margin value to use.
            fig_size (Tuple[float, float] | None, optional): the size of the figure. Defaults to None.

        Returns:
            Margin: the calculate margin.
        """
        if fig_size is None:
            return {
                "left": margin,
                "top": 1. - margin,
                "right": 1. - margin,
                "bottom": margin
            }
        else:
            return {
                "left": margin / fig_size[0],
                "top": 1. - (margin / fig_size[1]),
                "right": 1. - (margin / fig_size[0]),
                "bottom": margin / fig_size[1]
            }

    @staticmethod
    def calc_margin_single(margin: Tuple[float, float, float, float], fig_size: Tuple[float, float] | None = None) -> Margin:
        """Generates the margin of a figure, based on a multiple values. If @fig_size is give, it will calculate the absolute values within the figure size. 

        Args:
            margin (Tuple[float, float, float, float]): the margin values to use. The order is left, top, right, bottom.
            fig_size (Tuple[float, float] | None, optional): the size of the figure. Defaults to None.

        Returns:
            Margin: the calculate margin.
        """
        if fig_size is None:
            return {
                "left": margin[0],
                "top": 1. - margin[1],
                "right": 1. - margin[2],
                "bottom": margin[3]
            }
        else:
            return {
                "left": margin[0] / fig_size[0],
                "top": 1. - (margin[1] / fig_size[1]),
                "right": 1. - (margin[2] / fig_size[0]),
                "bottom": margin[3] / fig_size[1]
            }

    @staticmethod
    def calc_spacing_complete(spacing: float, fig_size: Tuple[float, float] | None = None) -> Spacing:
        """Generates the spacing of a figure, based on a single value. If @fig_size is give, it will calculate the absolute values within the figure size. 

        Args:
            spacing (float): the spacing value to use.
            fig_size (Tuple[float, float] | None, optional): the size of the figure. Defaults to None.

        Returns:
            Spacing: the calculate spacing.
        """
        if fig_size is None:
            return {
                "vertical": spacing,
                "horizontal": spacing
            }
        else:
            return {
                "vertical": spacing / fig_size[0],
                "horizontal": spacing / fig_size[1]
            }

    @staticmethod
    def calc_spacing_single(spacing: float, fig_size: Tuple[float, float] | None = None) -> Spacing:
        """Generates the spacing of a figure, based on a multiple values. If @fig_size is give, it will calculate the absolute values within the figure size. 

        Args:
            spacing (Tuple[float, float]): the spacing values to use. The order is vertical, horizontal.
            fig_size (Tuple[float, float] | None, optional): the size of the figure. Defaults to None.

        Returns:
            Spacing: the calculate spacing.
        """
        if fig_size is None:
            return {
                "vertical": spacing[0],
                "horizontal": spacing[1]
            }
        else:
            return {
                "vertical": spacing[0] / fig_size[0],
                "horizontal": spacing[1] / fig_size[1]
            }

    @staticmethod
    def calc_ylim(minY: float, maxY: float, other_dist: float = None):
        dist = abs(maxY - minY) if other_dist is None else other_dist
        return [minY - FigConfig.ylimFactor * dist, maxY + FigConfig.ylimFactor * dist]

    @staticmethod
    def set_rc_plot_values():
        plt.rcParams.update(FigConfig.RC_UPDATE)


    VisConfigs = {
        "eligible - year": VisConfig(
            ColorPalette={
                "Yes": COLOR_PALETTES['apple green'][1],
                "No (Screening)": COLOR_PALETTES["chili red"][0],
                "No (Eligible)": COLOR_PALETTES['chili red'][3]
            },
            categories=["Yes", "No (Screening)", "No (Eligible)"],
            xColumn="year",
            xLabel="Years",
            yLabel="Count",
            legendLabel="In Corpus",
            FileName="eligible - year"
        ),
        "source - years": VisConfig(          
            ColorPalette={DataConfig.Categories["source"][i]: COLOR_BREWER['qualitative-3'][i] for i in range(0, len(DataConfig.Categories["source"]))},
            categories=DataConfig.Categories["source"],
            xColumn="year",
            xLabel="Years",
            yLabel="Count",
            legendLabel="Sources",
            FileName="source - year"
        ),        
        "eligibility reason - year": VisConfig(
            ColorPalette={DataConfig.Categories["eligibility check"][i]: COLOR_BREWER['diverging-1'][i] for i in range(0, len(DataConfig.Categories["eligibility check"]))},
            categories=DataConfig.Categories["eligibility check"],
            xColumn="year",
            xLabel="Years",
            yLabel="Count",
            legendLabel="Reasons",
            FileName="eligibility reason - year"
        ),       
        "eligibility reason - source": VisConfig(
            ColorPalette={DataConfig.Categories["eligibility check"][i]: COLOR_BREWER['diverging-1'][i] for i in range(0, len(DataConfig.Categories["eligibility check"]))},
            categories=DataConfig.Categories["eligibility check"],
            xColumn="source",
            xLabel="Sources",
            yLabel="Count",
            legendLabel="Reasons",
            FileName="eligibility reason - source"
        ),  
        "code-contribution": VisConfig(
            ColorPalette={DataConfig.Categories["contribution"][i]: COLOR_BREWER['qualitative-1'][i] for i in range(0, len(DataConfig.Categories["contribution"]))},
            categories=DataConfig.Categories["contribution"],
            yColumn="Index",
            xLabel="Count",
            yLabel="",
            legendLabel="Main Contribution",
            FileName="code-contribution"
        ),
        # >>> correlation
        "terms - correlation": VisConfig(
            categories=DataConfig.Categories["terminology"],
            FileName="correlation- terms"
        ),
        "devices - correlation": VisConfig(
            categories=DataConfig.Categories["devices"],
            FileName="correlation- devices"
        ),
        "contribution+evaluation - correlation": VisConfig(
            categories=[c 
                        for g in ["contribution", "evaluation"]
                        for c in DataConfig.Categories[g]],
            FileName="correlation- contribution+evaluation"
        ),
        "taxonomy - correlation": VisConfig(
            categories=[c 
                        for g in ["temporal", "configuration", "relations", "scale", "dynamics", "codependency", "space", "mr anchoring"]
                        for c in DataConfig.Categories[g]],
            FileName="correlation- taxonomy"
        ),
        # >>> heatmap
        "taxonomy - configuration (heatmap)": VisConfig(
            categories=[c
                        for g in ["temporal", "relations", "scale", "dynamics", "space", "codependency", "mr anchoring"]
                        for c in DataConfig.Categories[g]],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="configuration",
            FileName="hm_ taxonomy - configuration"
        ),
        "mr device - 2d device (heatmap)": VisConfig(
            categories=DataConfig.Categories["2D devices"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="ar devices",
            FileName="hm_ mr device - 2d device"
        ),

        "terminology - year (heatmap)": VisConfig(
            categories=DataConfig.Categories["terminology"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="year",
            FileName="hm_ terminology - year"
        ),
        "devices - year (heatmap)": VisConfig(
            categories=DataConfig.Categories["devices"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="year",
            FileName="hm_ devices - year"
        ),      
        "contribution - year (heatmap)": VisConfig(
            categories=DataConfig.Categories["contribution"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="year",
            FileName="hm_ contribution - year"
        ),        
        "evaluation - year (heatmap)": VisConfig(
            categories=DataConfig.Categories["evaluation"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="year",
            FileName="hm_ evaluation - year"
        ),    

        "year - devices (heatmap)": VisConfig(
            categories=DataConfig.Categories["year-reduced"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="devices-reduced",
            FileName="hm_ year - devices"
        ),     
        "year - contribution (heatmap)": VisConfig(
            categories=DataConfig.Categories["year-reduced"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="contribution",
            FileName="hm_ year - contribution"
        ),     
        "year - evaluation (heatmap)": VisConfig(
            categories=DataConfig.Categories["year-reduced"],
            ColorPalette={"complete": COLOR_PALETTES["raisin black"]},
            yColumn="evaluation",
            FileName="hm_ year - evaluation"
        ),   
    }


